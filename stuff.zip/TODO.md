# TODO

Add in the Intents, Slots, etc - all the config to get the Skill running
Add in the zip command - required to upload to AWS
