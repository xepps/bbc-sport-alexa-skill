module.exports = {
  "session": {
    "sessionId": "SessionId.799124b3-c22b-4022-93da-1e6cf859a570",
    "application": {
      "applicationId": "amzn1.ask.skill.7cc2e7da-10bc-4600-ab4e-c51dc85e013c"
    },
    "attributes": {},
    "user": {
      "userId": "amzn1.ask.account.AFKP5WUOSEJN5M6TUCYTXIAKFNNRSTSPG3AYTTLWJ2WQSJC4IGFHS2TWLIMXHJYLWKJLBAVO22OYW23JVLWEXZM3BKPOLAJCIUXH3TPHXY63D7XCU4ZWCXGLQJKVEVVKAZR7PPGQWSG5NUBDSEDLR3HZPDJ7HNQKFCJUGCSGOS4W5XIHXJM4LSO44DRXZN7YYHWSUBR5AEU5GJY"
    },
    "new": true
  },
  "request": {
    "type": "IntentRequest",
    "requestId": "EdwRequestId.f9d92db0-4e2a-47c8-8007-c134707b7956",
    "locale": "en-GB",
    "timestamp": "2017-04-11T14:15:16Z",
    "intent": {
      "name": "NextFixture",
      "slots": {
        "Team": {
          "name": "Team",
          "value": "arsenal"
        }
      }
    }
  },
  "version": "1.0"
}
