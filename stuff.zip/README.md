# bbc-sport-alexa-skill

## Lambda local

 Make sure you have the latest version of Node (this is known to run on 7.8) and then `npm install lambda-local`

 Run the command `lambda-local -l index.js -h handler -e sample-events/unknown_team.js` to run against a fictional team, or choose any of the real teams in the sample-events folder.


    

	
