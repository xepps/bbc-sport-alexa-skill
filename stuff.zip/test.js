var request = require('superagent');

request
    .get('http://push.api.bbci.co.uk/morph/data/bbc-morph-sport-football-scores-tabbed-teams-model/team/rick-and-morty/version/1.0.6')
    .end(function(err, res) {
        console.log(err);
        console.log(res);
    });
